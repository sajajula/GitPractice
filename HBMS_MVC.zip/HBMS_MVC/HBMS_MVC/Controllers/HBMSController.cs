﻿using HBMS_MVC.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;


namespace HBMS_MVC.Controllers
{
    public class HBMSController : Controller
    {
        public static UserAccount LoggedInUser=null;

        // GET: HBMS
        public ActionResult Home()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Home(string City,DateTime checkIn,DateTime checkOut,string roomType,string bedType)
        {
            //if (this.session["LoggedInUser"] != null)
            //{
            string searchby = null;
            if (City == null || City == "")
            {
                ModelState.AddModelError("City", "Please Enter Valid City");
            }
            if((roomType == null || roomType == "") && (bedType == "" || bedType == null))
            {
                searchby = "dates";
            }
            if ((roomType == null || roomType == "") && (bedType != "" && bedType != null))
            {
                searchby = "bedtype";
            }
            if ((bedType == null || bedType == "") && (roomType != "" && roomType != null))
            {
                searchby = "roomtype";
            }
            switch (roomType)
            {
                case "1":
                    roomType = "Deluxe";
                    break;
                case "2":
                    roomType = "Standard";
                    break;
            }
            switch(bedType)
            {
            case "1":
                bedType = "Single(1X)";
                break;
            case "2":
                bedType = "Classic(2X)";
                break;
            case "3":
                bedType = "Suit(3X)";
                break;
            }
            if (ModelState.IsValid)
            {
                List<ModelForHotel> result=new List<ModelForHotel>();
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    string query = null;
                    if (searchby==null)
                    {
                        query = $"HBMS/GetHotelByTypesAndBeds?location={City}&bookingfrom={checkIn}&bookingto={checkOut}&roomtype={roomType}&beds={bedType}";
                    }
                    if(searchby=="roomtype")
                    {
                        query = $"HBMS/GetHotelByType?location={City}&roomtype={roomType}&bookingfrom={checkIn}&bookingto={checkOut}";
                    }
                    if(searchby=="bedtype")
                    {
                        query = $"HBMS/GetHotelByBeds?location={City}&beds={bedType}&bookingfrom={checkIn}&bookingto={checkOut}";
                    }
                    if(searchby=="dates")
                    {
                        query = $"HBMS/GetHotelsByLocationAndDates?location={City}&bookingfrom={checkIn}&bookingto={checkOut}";
                    }
                    var responseTask = client.GetAsync(query);
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<List<ModelForHotel>>();
                        readTask.Wait();
                        result = readTask.Result;
                    }
                }
               
                List<ModelForHotel> modelForHotel = new List<ModelForHotel>();
                List<int> hotelids = new List<int>();
                foreach (var item in result)
                {
                    ModelForHotel mh = new ModelForHotel();
                    bool isThere = false;
                    foreach (var i in hotelids)
                    {
                        if(Convert.ToInt32(i)==item.roomDetails.HotelID)
                        {
                            isThere = true;
                        }
                    }
                    if(!isThere)
                    {
                        hotelids.Add(item.roomDetails.HotelID);
                        mh=item;
                        mh.userAccount = LoggedInUser;
                        mh.checkIn = checkIn;
                        mh.checkOut = checkOut;
                        mh.roomType = roomType;
                        mh.bedType = bedType;
                        mh.Location = City;
                        modelForHotel.Add(mh);
                    }
                    
                }
                return View("SearchHotels",modelForHotel);

            }
            //}
            return View();
        }
        public ActionResult UserAccount()
        {
            return View(LoggedInUser);
        }

        [HttpPost]
        public ActionResult SearchRooms(string HotelID,string City, DateTime checkIn, DateTime checkOut, string roomType, string bedType)
        {
            //if (LoggedInUser != null)
            //{
            string searchby = null;
            if (City == null || City == "")
            {
                ModelState.AddModelError("City", "Please Enter Valid City");
            }
            if ((roomType == null || roomType == "") && (bedType == "" || bedType == null))
            {
                searchby = "dates";
            }
            if ((roomType == null || roomType == "") && (bedType != "" && bedType != null))
            {
                searchby = "bedtype";
            }
            if ((bedType == null || bedType == "") && (roomType != "" && roomType != null))
            {
                searchby = "roomtype";
            }
            
            if (ModelState.IsValid)
            {
                List<RoomDetails> result = new List<RoomDetails>();
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    string query = null;
                    if (searchby == null)
                    {
                        query = $"HBMS/GetRoomsByTypesAndBeds?hotelId={HotelID}&location={City}&bookingfrom={checkIn}&bookingto={checkOut}&roomtype={roomType}&beds={bedType}";
                    }
                    if (searchby == "roomtype")
                    {
                        query = $"HBMS/GetRoomsTypes?hotelId={HotelID}&location={City}&roomtype={roomType}&bookingfrom={checkIn}&bookingto={checkOut}";
                    }
                    if (searchby == "bedtype")
                    {
                        query = $"HBMS/GetRoomsByBeds?hotelId={HotelID}&location={City}&beds={bedType}&bookingfrom={checkIn}&bookingto={checkOut}";
                    }
                    if (searchby == "dates")
                    {
                        query = $"HBMS/GetRoomsByLocationAndDates?hotelId={HotelID}&location={City}&bookingfrom={checkIn}&bookingto={checkOut}";
                    }
                    var responseTask = client.GetAsync(query);
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<List<RoomDetails>>();
                        readTask.Wait();
                        result = readTask.Result;
                    }
                }
                ModelForBooking modelForBooking = new ModelForBooking();
                modelForBooking.roomDetails = result;
                modelForBooking.userAccount = LoggedInUser;
                modelForBooking.checkIn = checkIn;
                modelForBooking.checkOut = checkOut;
                modelForBooking.roomType = roomType;
                return View("SearchRooms", modelForBooking);
            }
            //}
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(string pwdold, string pwdnew, string pwdcheck)
        {
            if (pwdold == "")
            {
                ModelState.AddModelError("pwdold", "Please Enter Old Password");
            }
            if (pwdnew == "")
            {
                ModelState.AddModelError("pwdnew", "Please Enter New Password");
            }
            if (pwdcheck == "")
            {
                ModelState.AddModelError("pwdcheck", "Please Enter Password for Confirmation");
            }
            if (pwdold != "" && pwdnew != "" && pwdcheck != "")
            {
                if (pwdnew != pwdcheck)
                {
                    ModelState.AddModelError("pwdcheck", "Does Not Match With New Password");
                    return View();
                }
                else
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("http://localhost:65312/api/");
                        UserAccount user = LoggedInUser;
                        user.Password = pwdold;
                        var responseTask = client.PutAsJsonAsync<UserAccount>($"HBMS/ChangePassword?pwdold={user.Password}&passwordnew={pwdnew}", user);
                        responseTask.Wait();
                        var res = responseTask.Result;
                        if (res.IsSuccessStatusCode)
                        {
                            var readTask = res.Content.ReadAsAsync<bool>();
                            readTask.Wait();
                            if (readTask.Result)
                            {
                                TempData["SuccessMessage"] = "Password Has Been Changed Successfully";
                                return RedirectToAction("UserAccount");
                            }
                            else
                            {
                                ModelState.AddModelError("isvalid", "Invalid Password");
                            }
                        }
                    }
                }

            }
            return View();
        }

        public ActionResult RegisterUser()
        {
            UserAccount user = new UserAccount();
            return View(user);
        }

        public ActionResult ChangePassword()
        {
            return View();
        }

        public ActionResult ChangeDetails()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangeDetails(string username, string email, string phoneno, string name)
        {
            UserAccount user = new UserAccount();
            user.UserName = username;
            user.Email = email;
            user.PhoneNo = phoneno;
            user.Name = name;
            if (name == "")
            {
                ModelState.AddModelError("name", "Please Enter Your Name");
            }
            if (!Regex.IsMatch(name, "^[\\p{L} .'-]+$"))
            {
                ModelState.AddModelError("name", "Invalid Name");
            }
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api");
                    var responseTask = client.PutAsJsonAsync("HBMS/UpdateDetails", user);
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        if (readTask.Result)
                        {
                            LoggedInUser.Name = name;
                            return RedirectToAction("UserAccount");
                        }
                    }
                }
            }
            return View(user);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterUser([Bind(Include = "UserId,UserName,Email,PhoneNo,Name,Password,UserType")]UserAccount user, string Confirm_Password, string Passcode, int? hotelid)
        {
            if (ModelState.IsValid)
            {
                int result = 0;
                if (user.UserType == "Employee" && Passcode != "secretpasscode@capgemini.com")
                {
                    ModelState.AddModelError("Passcode", "Invalid Passcode");
                    ViewBag.Passcode = Passcode;
                    return View(user);
                }
                if (user.UserType == "Employee" && hotelid == null)
                {
                    ModelState.AddModelError("hotelid", "Please Enter Hotel ID");
                    ViewBag.Passcode = Passcode;
                    return View(user);
                }
                if (user.UserType == "Employee" && hotelid != null)
                {
                    Hotel hotel = null;
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("http://localhost:65312/api/");
                        var responseTask = client.GetAsync($"HBMS/GetHotelByID?id={hotelid}");
                        responseTask.Wait();
                        var res = responseTask.Result;
                        if (res.IsSuccessStatusCode)
                        {
                            var readTask = res.Content.ReadAsAsync<Hotel>();
                            readTask.Wait();
                            if (readTask.Result != null)
                            {
                                hotel = (Hotel)readTask.Result;
                            }
                            if (hotel != null)
                            {
                                if (hotel.HotelName == null || hotel.HotelName == "")
                                {
                                    hotel = null;
                                }
                            }
                        }
                    }
                    if (hotel == null)
                    {
                        ModelState.AddModelError("hotelid", "Invalid Hotel ID");
                        ViewBag.Passcode = Passcode;
                        ViewBag.hotelid = hotelid;
                        return View(user);
                    }
                }
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/UserAlreadyExist?username={user.UserName}&email={user.Email}&phoneno={user.PhoneNo}");
                    responseTask.Wait();

                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<Int32>();
                        readTask.Wait();
                        result = readTask.Result;
                    }
                }

                if (user.Password != Confirm_Password)
                {
                    ModelState.AddModelError("Confirm_Password", "Does Not Match With Password");
                }
                else if (result == 0)
                {

                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("http://localhost:65312/api/");
                        var postTask = client.PostAsJsonAsync<UserAccount>($"HBMS/PostUser?username{user.UserName}", user);
                        postTask.Wait();

                        var res = postTask.Result;
                        if (res.IsSuccessStatusCode)
                        {
                            var readTask = res.Content.ReadAsAsync<bool>();
                            readTask.Wait();
                            if (readTask.Result)
                            {
                                if (user.UserType == "Employee")
                                {
                                    using (var empclient = new HttpClient())
                                    {
                                        empclient.BaseAddress = new Uri("http://localhost:65312/api/");
                                        var emppostTask = empclient.PostAsJsonAsync<UserAccount>($"HBMS/PostEmployee?username={user.UserName}&hotelid={hotelid}", user);
                                        emppostTask.Wait();
                                        var empres = postTask.Result;
                                        if (empres.IsSuccessStatusCode)
                                        {
                                            TempData["SuccessMessage"] = "Registered Successfully";
                                            return RedirectToAction("Login", "HBMS");
                                        }
                                    }
                                }
                                TempData["SuccessMessage"] = "Registered Successfully";
                                return RedirectToAction("Login", "HBMS");

                            }
                        }
                    }
                }
                if (result % 10 == 1)
                {
                    ModelState.AddModelError("UserName", "Entered UserName Not Available");
                }
                if ((result / 10) % 10 == 1)
                {
                    ModelState.AddModelError("Email", $"An account already exists with {user.Email}");
                }
                if (result / 100 == 1)
                {
                    ModelState.AddModelError("PhoneNo", $"An account already exists with {user.PhoneNo}");
                }

            }
            return View(user);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(string loginid, string password)
        {
            UserAccount result = null;
            if (loginid == "")
            {
                ModelState.AddModelError("loginid", $"Please Enter UserName/Email ID");
            }
            if (password == "")
            {
                ModelState.AddModelError("password", $"Please Enter Password");
            }
            if (loginid != "" && password != "")
            {

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/Login?loginid={loginid}&password={password}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<UserAccount>();
                        readTask.Wait();
                        result = readTask.Result;
                        if (result != null)
                        {
                            LoggedInUser = (UserAccount)result;
                            if (LoggedInUser != null)
                            {
                                TempData["SuccessMessage"] = "Logged In Successfully";
                            }
                            return RedirectToAction("Home");
                        }
                        else
                        {
                            ModelState.AddModelError("isvalid", "Invalid Login ID/Password");
                        }
                    }
                }
            }
            ViewBag.UserName = loginid;
            ViewBag.Password = "";
            return View();
        }

        [HttpPost]
        public ActionResult BookHotel(string GuestName,string hotelId, string noOfRooms, string noOfGuests, string totalPrice, string breakfast, string roomType, string bedType, string checkIn, string checkOut)
        {
            if (LoggedInUser != null)
            {
                using (var client = new HttpClient())
                {
                    List<string> send = new List<string>();
                    send.Add(Convert.ToString(LoggedInUser.UserID));
                    send.Add(GuestName);
                    send.Add(roomType);
                    send.Add(hotelId);
                    send.Add(checkIn);
                    send.Add(checkOut);
                    send.Add(bedType);
                    send.Add(noOfGuests);
                    if (breakfast == "true")
                        breakfast = "Yes";
                    else
                        breakfast = "No";
                        send.Add(breakfast);
                    //double days=(Convert.ToDateTime(checkOut) - Convert.ToDateTime(checkIn)).TotalDays;
                    //totalPrice = (Convert.ToDouble(totalPrice) * days).ToString();
                    send.Add(totalPrice);
                    //int userID,string guestName, string roomtype, int hotelid, DateTime BookingFrom,DateTime BookingTo, string beds,int GuestNum,string BreakfastIncluded,int TotalAmount
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var postTask = client.PostAsJsonAsync("HBMS/PostBookRooms",send);
                    postTask.Wait();

                    var res = postTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        if (readTask.Result)
                        {
                            TempData["SuccessMessage"] = $"Room Booked Successfully..!";
                            return RedirectToAction("Home", "HBMS");
                        }
                    }
                }
                return View("Home");
            }
            return View("Login");
        }
        public ActionResult LoggedIn()
        {
            if(LoggedInUser!=null)
            {
                return View(LoggedInUser);
            }
            return View();
        }

        public ActionResult AdminMenu()
        {
            return View();
        }

        public ActionResult LoggedOut()
        {

            LoggedInUser = null;
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }




        public ActionResult BookingDetails()
        {
            List<Bookings> result = new List<Bookings>();
            if (LoggedInUser != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/GetBookingsByUser?userid={LoggedInUser.UserID}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<List<Bookings>>();
                        readTask.Wait();
                        result = readTask.Result;
                    }

                }
            }
            
            return View(result);
        }
        //[HttpPost]
        //public ActionResult RateHotel(int bookingID)
        //{
        //    return View();
        //}


        [HttpPost]
        public ActionResult RateHotel(int hotelID,int bookingID,int RatedValue)
        {
            bool result = false;
            if (LoggedInUser != null)
            {

                using (var client = new HttpClient())
                {
                    List<int> list = new List<int>();
                    list.Add(hotelID);
                    list.Add(bookingID);
                    list.Add(RatedValue);
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var postTask = client.PostAsJsonAsync<List<int>>("HBMS/PostUserRating", list);
                    postTask.Wait();

                    var res = postTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        if (readTask.Result)
                        {
                            return RedirectToAction("BookingDetails", "HBMS");
                        }
                    }
                }
 
                if(!result)
                {
                    ModelState.AddModelError("rating", "Error While recording your rating");
                }
            }
            return RedirectToAction("BookingDetails");
        }

        public ActionResult CancelBooking(int bookingID)
        {
            List<Bookings> result = new List<Bookings>();
            if (LoggedInUser != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/GetBookingsByUser?userid={LoggedInUser.UserID}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<List<Bookings>>();
                        readTask.Wait();
                        result = readTask.Result;
                        
                    }

                }
            }

            return View(result);
        }
        public ActionResult slideshow()
        {
            return View();
        }
        [HttpPost, ActionName("CancelBooking")]
        public ActionResult CancelBookingConfirmed(int bookingID)
        {
            bool result = false;
            if (LoggedInUser != null)
            {

                using (var client = new HttpClient())
                {
                    
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var postTask = client.PostAsJsonAsync<UserAccount>($"HBMS/PostCancelRoomsByID?bookingid={bookingID}", LoggedInUser);
                    postTask.Wait();

                    var res = postTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        if (readTask.Result)
                        {
                            TempData["SuccessMessage"] = $"Booking ID : {bookingID} has been cancelled";
                            return RedirectToAction("BookingDetails", "HBMS");
                        }
                    }
                }

                if (!result)
                {
                    ModelState.AddModelError("rating", "Error While cancelling your booking");
                }
            }
            return RedirectToAction("BookingDetails");
        }





        //Sdeep

        public ActionResult AddHotel()
        {
            List<string> choice = new List<string>() { "Yes", "No" };
            List<object> type = new List<object>() { new { type = "*****", name = "5 Star" }, new { type = "****", name = "4 Star" }, new { type = "***", name = "3 Star" }, new { type = "**", name = "2 Star" }, new { type = "*", name = "1 Star" } };

            ViewBag.HotelType = new SelectList(type, "type", "name");
            ViewBag.WiFi = new SelectList(choice);
            ViewBag.Geyser = new SelectList(choice);

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddHotel([Bind(Include = "HotelID,HotelName,Location,HotelType,Rating,WiFi,Geyser,StartingAt,Discount")] Hotel hotel)        //This will add the complaint to the database.
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var postTask = client.PostAsJsonAsync<Hotel>("HBMS/PostHotel?", hotel);
                    postTask.Wait();

                    var res = postTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        if (readTask.Result)
                        {
                            TempData["SuccessMessage"] = "Hotel Added Successfully";
                            return RedirectToAction("HotelList");
                        }
                    }
                }
            }
            List<string> choice = new List<string>() { "Yes", "No" };
            List<object> type = new List<object>() { new { type = "*****", name = "5 Star" }, new { type = "****", name = "4 Star" }, new { type = "***", name = "3 Star" }, new { type = "**", name = "2 Star" }, new { type = "*", name = "1 Star" } };
            ViewBag.HotelType = new SelectList(type, "type", "name");
            ViewBag.WiFi = new SelectList(choice);
            ViewBag.Geyser = new SelectList(choice);
            return View(hotel);
        }

        public ActionResult AddRoom()
        {
            List<string> choice1 = new List<string>() { "Single(1X)", "Classic(2X)", "Suite(3X)" };
            List<string> choice2 = new List<string>() { "Deluxe", "Standard" };
            List<Hotel> hotels = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotels");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<Hotel>>();
                    readTask.Wait();

                    hotels = readTask.Result;
                }
            }
            ViewBag.HotelID = new SelectList(hotels, "HotelID", "HotelName");
            ViewBag.Beds = new SelectList(choice1);
            ViewBag.RoomType = new SelectList(choice2);
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddRoom([Bind(Include = "RoomID,RoomNo,HotelID,HotelName,Price,Beds,RoomType")] RoomDetails room)        //This will add the complaint to the database.
        {
            if (ModelState.IsValid)
            {
                bool isvalid = true;
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/CheckRoomNo?RoomNo={room.RoomNo}&Hotelid={room.HotelID}");
                    responseTask.Wait();

                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        isvalid = (bool)readTask.Result;
                    }
                }

                if (isvalid)
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("http://localhost:65312/api/");
                        var postTask = client.PostAsJsonAsync<RoomDetails>("HBMS/PostRoom?", room);
                        postTask.Wait();

                        var res = postTask.Result;
                        if (res.IsSuccessStatusCode)
                        {
                            var readTask = res.Content.ReadAsAsync<bool>();
                            readTask.Wait();
                            if (readTask.Result)
                            {
                                TempData["SuccessMessage"] = "Room Added Successfully";
                                return RedirectToAction("RoomList");
                            }
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("RoomNo", "This Room No is already in the hotel");
                }
            }
            List<string> choice1 = new List<string>() { "Single(1X)", "Classic(2X)", "Suite(3X)" };
            List<string> choice2 = new List<string>() { "Deluxe", "Standard" };
            List<Hotel> hotels = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotels");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<Hotel>>();
                    readTask.Wait();

                    hotels = readTask.Result;
                }
            }
            ViewBag.HotelID = new SelectList(hotels, "HotelID", "HotelName");
            ViewBag.Beds = new SelectList(choice1);
            ViewBag.RoomType = new SelectList(choice2);
            return View(room);
        }

        public ActionResult UpdateHotel(int? id)
        {
            List<string> choice = new List<string>() { "Yes", "No" };
            List<object> type = new List<object>() { new { type = "*****", name = "5 Star" }, new { type = "****", name = "4 Star" }, new { type = "***", name = "3 Star" }, new { type = "**", name = "2 Star" }, new { type = "*", name = "1 Star" } };
            Hotel hotel = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotelByID?id={id}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<Hotel>();
                    readTask.Wait();
                    var result = readTask.Result;
                    if (result != null)
                    {
                        hotel = (Hotel)result;
                    }
                }
            }
            ViewBag.HotelType = new SelectList(type, "type", "name");
            ViewBag.WiFi = new SelectList(choice);
            ViewBag.Geyser = new SelectList(choice);
            hotel.Discount = hotel.Discount * 100;
            return View(hotel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateHotel([Bind(Include = "HotelID,HotelName,Location,HotelType,Rating,WiFi,Geyser,StartingAt,Discount")] Hotel hotel)   //It will edit and save the complaint
        {
            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.PutAsJsonAsync<Hotel>($"HBMS/PutHotelByID?", hotel);
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        if (readTask.Result)
                        {
                            TempData["SuccessMessage"] = "Hotel Record Updated Successfully";
                            return RedirectToAction("HotelList");
                        }
                    }
                }

            }
            List<string> choice = new List<string>() { "Yes", "No" };
            List<object> type = new List<object>() { new { type = "*****", name = "5 Star" }, new { type = "****", name = "4 Star" }, new { type = "***", name = "3 Star" }, new { type = "**", name = "2 Star" }, new { type = "*", name = "1 Star" } };
            ViewBag.HotelType = new SelectList(type, "type", "name");
            ViewBag.WiFi = new SelectList(choice);
            ViewBag.Geyser = new SelectList(choice);
            return View(hotel);
        }

        public ActionResult UpdateRoom(int? id)
        {
            List<string> choice1 = new List<string>() { "Single(1X)", "Classic(2X)", "Suite(3X)" };
            List<string> choice2 = new List<string>() { "Deluxe", "Standard" };
            List<Hotel> hotels = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotels");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<Hotel>>();
                    readTask.Wait();

                    hotels = readTask.Result;
                }
            }

            ViewBag.Beds = new SelectList(choice1);
            ViewBag.RoomType = new SelectList(choice2);

            RoomDetails room = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetRoomByID?id={id}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<RoomDetails>();
                    readTask.Wait();
                    var result = readTask.Result;
                    if (result != null)
                    {
                        room = (RoomDetails)result;
                    }
                }
            }

            return View(room);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateRoom([Bind(Include = "RoomID,RoomNo,HotelID,HotelName,Price,Beds,RoomType")] RoomDetails room)
        {

            if (ModelState.IsValid)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.PutAsJsonAsync<RoomDetails>($"HBMS/PutRoomByID?", room);
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<bool>();
                        readTask.Wait();
                        if (readTask.Result)
                        {
                            TempData["SuccessMessage"] = "Room Record Updated Successfully";
                            return RedirectToAction("RoomList");
                        }
                    }
                }

            }

            List<string> choice1 = new List<string>() { "Single(1X)", "Classic(2X)", "Suite(3X)" };
            List<string> choice2 = new List<string>() { "Deluxe", "Standard" };
            List<Hotel> hotels = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotels");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<Hotel>>();
                    readTask.Wait();

                    hotels = readTask.Result;
                }
            }
            ViewBag.Beds = new SelectList(choice1);
            ViewBag.RoomType = new SelectList(choice2);
            return View(room);
        }

        public ActionResult RemoveHotel(int? id)
        {
            List<string> choice = new List<string>() { "Yes", "No" };
            List<object> type = new List<object>() { new { type = "*****", name = "5 Star" }, new { type = "****", name = "4 Star" }, new { type = "***", name = "3 Star" }, new { type = "**", name = "2 Star" }, new { type = "*", name = "1 Star" } };
            Hotel hotel = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotelByID?id={id}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<Hotel>();
                    readTask.Wait();
                    var result = readTask.Result;
                    if (result != null)
                    {
                        hotel = (Hotel)result;
                    }
                }
            }
            ViewBag.HotelType = new SelectList(type, "type", "name");
            ViewBag.WiFi = new SelectList(choice);
            ViewBag.Geyser = new SelectList(choice);
            return View(hotel);
        }

        [HttpPost, ActionName("RemoveHotel")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id) //This will confirm deletion
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var postTask = client.DeleteAsync($"HBMS/DeleteHotelByID?id={id}");
                postTask.Wait();

                var res = postTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<bool>();
                    readTask.Wait();
                    if (readTask.Result)
                    {
                        TempData["SuccessMessage"] = "Hotel Removed Successfully";
                        return RedirectToAction("HotelList");
                    }
                }
            }
            return RedirectToAction("HotelList");
        }

        public ActionResult RemoveRoom(int? id)
        {
            RoomDetails room = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetRoomByID?id={id}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<RoomDetails>();
                    readTask.Wait();
                    var result = readTask.Result;
                    if (result != null)
                    {
                        room = (RoomDetails)result;
                    }
                }
            }

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotelByID?id={room.HotelID}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<Hotel>();
                    readTask.Wait();
                    var result = readTask.Result;
                    if (result != null)
                    {
                        room.HotelName = ((Hotel)result).HotelName;
                    }
                }
            }

            return View(room);
        }

        [HttpPost, ActionName("RemoveRoom")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmedRoom(int id) //This will confirm deletion
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var postTask = client.DeleteAsync($"HBMS/DeleteRoomByID?id={id}");
                postTask.Wait();

                var res = postTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<bool>();
                    readTask.Wait();
                    if (readTask.Result)
                    {
                        TempData["SuccessMessage"] = "Room Removed Successfully";
                        return RedirectToAction("RoomList");
                    }
                }
            }
            return RedirectToAction("RoomList");
        }

        public ActionResult HotelList()
        {
            List<Hotel> hotels = new List<Hotel>();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotels");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<Hotel>>();
                    readTask.Wait();

                    hotels = readTask.Result;
                }
            }

            return View(hotels);
        }

        public ActionResult RoomList()
        {
            List<RoomDetails> rooms = new List<RoomDetails>();

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetRooms");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<RoomDetails>>();
                    readTask.Wait();

                    rooms = readTask.Result;
                }
            }

            return View(rooms);
        }

        public ActionResult BookingListDate(DateTime? Date)
        {
            IEnumerable<BookingDetail> details = null;

            if (Date != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/GetBookingsByDate?searchdate={Date}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<IEnumerable<BookingDetail>>();
                        readTask.Wait();
                        var result = readTask.Result;
                        if (result != null)
                        {
                            details = (IEnumerable<BookingDetail>)result;
                        }
                    }
                }
            }

            return View(details);
        }

        public ActionResult BookingListHotel(int? HotelID)
        {
            IEnumerable<BookingDetail> details = null;
            if (HotelID != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/GetAllHotelBookings?hotelid={HotelID}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<IEnumerable<BookingDetail>>();
                        readTask.Wait();
                        var result = readTask.Result;
                        if (result != null)
                        {
                            details = (IEnumerable<BookingDetail>)result;
                        }
                    }
                }
            }

            List<Hotel> hotels = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotels");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<Hotel>>();
                    readTask.Wait();

                    hotels = readTask.Result;
                }
            }
            ViewBag.HotelID = new SelectList(hotels, "HotelID", "HotelName");

            return View(details);
        }

        public ActionResult GuestListHotel(int? HotelID)
        {
            IEnumerable<BookingDetail> details = null;
            if (HotelID != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/GetAllHotelBookings?hotelid={HotelID}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<IEnumerable<BookingDetail>>();
                        readTask.Wait();
                        var result = readTask.Result;
                        if (result != null)
                        {
                            details = (IEnumerable<BookingDetail>)result;
                        }
                    }
                }
            }

            List<Hotel> hotels = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:65312/api/");
                var responseTask = client.GetAsync($"HBMS/GetHotels");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<Hotel>>();
                    readTask.Wait();

                    hotels = readTask.Result;
                }
            }
            ViewBag.HotelID = new SelectList(hotels, "HotelID", "HotelName");

            return View(details);
        }

        public ActionResult EditBooking(int? id)
        {
            BookingDetail booking = new BookingDetail();

            return View();
        }

        public ActionResult EditBooking(BookingDetail booking)
        {
            return View(booking);
        }

        public ActionResult ViewBookingDetails()
        {
            int? HotelID = null;
            if (LoggedInUser.UserType == "Employee")
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/SearchEmployee?userid={LoggedInUser.UserID}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<EmployeesByHotel>();
                        readTask.Wait();
                        HotelID = ((EmployeesByHotel)readTask.Result).HotelID;
                    }
                }
            }

            IEnumerable<BookingDetail> details = new List<BookingDetail>();
            if (HotelID != null)
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:65312/api/");
                    var responseTask = client.GetAsync($"HBMS/GetAllHotelBookings?hotelid={HotelID}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<IEnumerable<BookingDetail>>();
                        readTask.Wait();
                        var result = readTask.Result;
                        if (result != null)
                        {
                            details = (IEnumerable<BookingDetail>)result;
                        }
                    }
                }
            }
            return View(details);
        }

    }

}
