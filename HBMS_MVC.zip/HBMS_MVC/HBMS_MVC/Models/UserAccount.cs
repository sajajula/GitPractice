﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace HBMS_MVC.Models
{
    public partial class UserAccount
    {
        public int UserID { get; set; }

        [Display(Name = "User Name")]
        [Required(ErrorMessage = "(Required)")]
        [StringLength(40)]
        [RegularExpression("^[A-Za-z0-9]+$")]
        public string UserName { get; set; }

        [Display(Name = "Email ID")]
        [Required(ErrorMessage = "(Required)")]
        [StringLength(40)]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Display(Name="Mobile No")]
        [Required(ErrorMessage = "(Required)")]
        [StringLength(10)]
        [RegularExpression("^[6-9][0-9]{9}$",ErrorMessage = "Invalid Phone No")]
        public string PhoneNo { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [StringLength(50)]
        [RegularExpression("^[\\p{L} .'-]+$",ErrorMessage = "Invalid Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [DataType(DataType.Password)]
        [StringLength(20,MinimumLength = 6, ErrorMessage = "Must be at least 6 characters long.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [StringLength(15)]
        public string UserType { get; set; }
    }
}