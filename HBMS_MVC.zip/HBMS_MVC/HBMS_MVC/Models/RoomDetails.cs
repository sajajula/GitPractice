namespace HBMS_MVC.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HBMS.RoomDetails")]
    public partial class RoomDetails
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public RoomDetails()
        {
            BookingDetails = new HashSet<BookingDetail>();
        }

        [Key]
        public int RoomID { get; set; }

        [Display(Name = "Room No")]
        [Required]
        public int RoomNo { get; set; }

        [Required]
        public int HotelID { get; set; }

        [Display(Name = "Hotel Name")]
        public string HotelName { get; set; }

        [Required]
        public double Price { get; set; }

        [Required]
        [StringLength(12)]
        public string Beds { get; set; }

        [Display(Name = "Room Type")]
        [Required]
        [StringLength(10)]
        public string RoomType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<BookingDetail> BookingDetails { get; set; }

        public virtual Hotel Hotel { get; set; }
    }
}
