﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBMS_MVC.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HBMS.EmployeesByHotel")]
    public partial class EmployeesByHotel
    {
        [Key]
        public int EmployeeID { get; set; }

        public int? UserID { get; set; }

        public int? HotelID { get; set; }

        [StringLength(40)]
        public string HotelName { get; set; }

        public virtual Hotel Hotel { get; set; }

        public virtual UserAccount User { get; set; }
    }
}