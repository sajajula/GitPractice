namespace HBMS_MVC.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HBMS.Hotels")]
    public partial class Hotel
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Hotel()
        {
            RoomDetails = new HashSet<RoomDetails>();
        }

        [Display(Name = "Hotel ID")]
        public int HotelID { get; set; }

        [Display(Name = "Hotel Name")]
        [Required]
        [StringLength(40)]
        public string HotelName { get; set; }

        [Required]
        [StringLength(30)]
        public string Location { get; set; }

        [Display(Name = "Hotel Type")]
        [Required]
        [StringLength(10)]
        public string HotelType { get; set; }

        public double? Rating { get; set; }

        [Required]
        [StringLength(5)]
        public string WiFi { get; set; }

        [Required]
        [StringLength(5)]
        public string Geyser { get; set; }

        [Display(Name = "Starting At")]
        public double StartingAt { get; set; }

        [Range(0, 100)]
        public double? Discount { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RoomDetails> RoomDetails { get; set; }
    }
}
