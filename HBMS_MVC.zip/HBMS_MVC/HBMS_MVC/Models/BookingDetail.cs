namespace HBMS_MVC.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HBMS.BookingDetails")]
    public partial class BookingDetail
    {
        [Key]
        public int BookingID { get; set; }

        public int UserID { get; set; }

        [Display(Name = "Guest Name")]
        [Required]
        [StringLength(40)]
        public string GuestName { get; set; }

        public int RoomID { get; set; }

        [Display(Name = "Hotel Name")]
        public string HotelName { get; set; }

        [Display(Name = "Room No")]
        public int RoomNo { get; set; }

        [Display(Name = "Booking From")]
        public DateTime BookingFrom { get; set; }

        [Display(Name = "Booking To")]
        public DateTime BookingTo { get; set; }

        [Display(Name = "Number of Guests")]
        public int GuestNum { get; set; }

        [Display(Name = "BreakFast Included?")]
        [Required]
        [StringLength(5)]
        public string BreakfastIncluded { get; set; }

        [Display(Name = "Total Amount")]
        public double TotalAmount { get; set; }

        [Display(Name = "Booking Status")]
        [Required]
        [StringLength(10)]
        public string BookingStatus { get; set; }

        public double? Rating { get; set; }

        public virtual RoomDetails RoomDetail { get; set; }
    }
}
