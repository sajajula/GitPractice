namespace HBMS_WebAPI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HBMS.RoomDetails")]
    public partial class RoomDetail
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public RoomDetail()
        {
            BookingDetails = new HashSet<BookingDetail>();
        }

        [Key]
        public int RoomID { get; set; }

        public int RoomNo { get; set; }

        public int HotelID { get; set; }

        public string HotelName { get; set; }

        public double Price { get; set; }

        [Required]
        [StringLength(12)]
        public string Beds { get; set; }

        [Required]
        [StringLength(10)]
        public string RoomType { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<BookingDetail> BookingDetails { get; set; }

        public virtual Hotel Hotel { get; set; }
    }
}
