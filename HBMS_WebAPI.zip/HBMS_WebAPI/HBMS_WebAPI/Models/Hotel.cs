namespace HBMS_WebAPI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HBMS.Hotels")]
    public partial  class Hotel
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Hotel()
        {
            EmployeesByHotels = new HashSet<EmployeesByHotel>();
            RoomDetails = new HashSet<RoomDetail>();
        }

        public int HotelID { get; set; }

        [Required]
        [StringLength(40)]
        public string HotelName { get; set; }

        [Required]
        [StringLength(30)]
        public string Location { get; set; }

        [Required]
        [StringLength(10)]
        public string HotelType { get; set; }

        public double? Rating { get; set; }

        [Required]
        [StringLength(5)]
        public string WiFi { get; set; }

        [Required]
        [StringLength(5)]
        public string Geyser { get; set; }

        public double StartingAt { get; set; }

        public double? Discount { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<EmployeesByHotel> EmployeesByHotels { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<RoomDetail> RoomDetails { get; set; }
    }
}
