namespace HBMS_WebAPI.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HBMS.BookingDetails")]
    public partial class BookingDetail
    {
        [Key]
        public int BookingID { get; set; }

        public int UserID { get; set; }

        [Required]
        [StringLength(40)]
        public string GuestName { get; set; }

        public int RoomID { get; set; }

        public DateTime BookingFrom { get; set; }

        public DateTime BookingTo { get; set; }

        public int GuestNum { get; set; }

        [Required]
        [StringLength(5)]
        public string BreakfastIncluded { get; set; }

        public double TotalAmount { get; set; }

        [Required]
        [StringLength(10)]
        public string BookingStatus { get; set; }

        public double? Rating { get; set; }

        public virtual RoomDetail RoomDetail { get; set; }

        public virtual User User { get; set; }
    }
}
