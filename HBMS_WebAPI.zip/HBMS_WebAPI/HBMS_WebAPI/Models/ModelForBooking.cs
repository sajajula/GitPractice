﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBMS_WebAPI.Models
{

        public class ModelForBooking
        {
            public List<RoomDetail> roomDetails { get; set; }
            public User userAccount { get; set; }
            public DateTime checkIn { get; set; }
            public DateTime checkOut { get; set; }
            public string roomType { get; set; }
            public string bedType { get; set; }
            public ModelForBooking()
            {

            }
        }
        public class ModelForHotel
        {
            public string HotelName { get; set; }
            public string Location { get; set; }
            public RoomDetail roomDetails { get; set; }
            public User userAccount { get; set; }
            public DateTime checkIn { get; set; }
            public DateTime checkOut { get; set; }
            public string roomType { get; set; }
            public string bedType { get; set; }
            public ModelForHotel()
            {

            }
        }
    
}