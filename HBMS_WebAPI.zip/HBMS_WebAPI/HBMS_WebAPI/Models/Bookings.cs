﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBMS_WebAPI.Models
{
    public class Bookings
    {
        public BookingDetail bookingDetail { get; set; }
        public int hotelID { get; set; }
        public string hotelName { get; set; }
        public bool isCheckedIn { get; set; }
        public bool isCancelled { get; set; }
        public Bookings()
        {
            this.bookingDetail = new BookingDetail();
        }


    }
}