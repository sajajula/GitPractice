namespace HBMS_WebAPI.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class HBMS : DbContext
    {
        public HBMS()
            : base("name=HBMS")
        {
        }

        public virtual DbSet<BookingDetail> BookingDetails { get; set; }
        public virtual DbSet<Hotel> Hotels { get; set; }
        public virtual DbSet<RoomDetail> RoomDetails { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<EmployeesByHotel> EmployeesByHotels { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BookingDetail>()
                .Property(e => e.GuestName)
                .IsUnicode(false);

            modelBuilder.Entity<BookingDetail>()
                .Property(e => e.BreakfastIncluded)
                .IsUnicode(false);

            modelBuilder.Entity<BookingDetail>()
                .Property(e => e.BookingStatus)
                .IsUnicode(false);

            modelBuilder.Entity<Hotel>()
                .Property(e => e.HotelName)
                .IsUnicode(false);

            modelBuilder.Entity<Hotel>()
                .Property(e => e.Location)
                .IsUnicode(false);

            modelBuilder.Entity<Hotel>()
                .Property(e => e.HotelType)
                .IsUnicode(false);

            modelBuilder.Entity<Hotel>()
                .Property(e => e.WiFi)
                .IsUnicode(false);

            modelBuilder.Entity<Hotel>()
                .Property(e => e.Geyser)
                .IsUnicode(false);

            modelBuilder.Entity<Hotel>()
                .HasMany(e => e.EmployeesByHotels)
                .WithOptional(e => e.Hotel)
                .WillCascadeOnDelete();

            modelBuilder.Entity<RoomDetail>()
                .Property(e => e.Beds)
                .IsUnicode(false);

            modelBuilder.Entity<RoomDetail>()
                .Property(e => e.RoomType)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.UserName)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.Email)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.PhoneNo)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.Name)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.UserType)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .HasMany(e => e.EmployeesByHotels)
                .WithOptional(e => e.User)
                .WillCascadeOnDelete();

            modelBuilder.Entity<EmployeesByHotel>()
                .Property(e => e.HotelName)
                .IsUnicode(false);
        }
    }
}
